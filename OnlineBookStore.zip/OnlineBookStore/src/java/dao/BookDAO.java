package dao;

import model.Book;

import javax.persistence.*;
import java.util.List;

public class BookDAO {

    private EntityManagerFactory emf;
    private EntityManager em;

    public BookDAO() {
        emf = Persistence.createEntityManagerFactory("OnlineBookStorePU");
        em = emf.createEntityManager();
    }

    // Create
    public void create(Book book) {
        em.getTransaction().begin();
        em.persist(book);
        em.getTransaction().commit();
    }

    // Read (Find by ID)
    public Book findById(int id) {
        return em.find(Book.class, id);
    }

    // Read (List all)
    public List<Book> findAll() {
        TypedQuery<Book> query = em.createQuery("SELECT b FROM Book b", Book.class);
        return query.getResultList();
    }

    // Update
    public void update(Book book) {
        em.getTransaction().begin();
        em.merge(book);
        em.getTransaction().commit();
    }

    // Delete
    public void delete(Book book) {
        em.getTransaction().begin();
        em.remove(em.merge(book));
        em.getTransaction().commit();
    }
}
